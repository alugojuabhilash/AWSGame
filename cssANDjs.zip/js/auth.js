import config from './config.js';

// Change to export class instead of default export
export class Auth {
    static async exchangeCodeForTokens(code) {
        const tokenEndpoint = `https://${config.domain}/oauth2/token`;
        const params = new URLSearchParams();
        params.append('grant_type', 'authorization_code');
        params.append('client_id', config.clientId);
        params.append('code', code);
        params.append('redirect_uri', config.redirectUri);

        try {
            const response = await fetch(tokenEndpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: params
            });

            const responseData = await response.text();
            if (!response.ok) {
                throw new Error(`Token exchange failed: ${responseData}`);
            }

            const tokens = JSON.parse(responseData);
            if (!tokens.access_token || !tokens.id_token) {
                throw new Error('Invalid token response: Missing required tokens');
            }

            // Store tokens
            localStorage.setItem('accessToken', tokens.access_token);
            localStorage.setItem('idToken', tokens.id_token);
            localStorage.setItem('refreshToken', tokens.refresh_token);

            return tokens;
        } catch (error) {
            console.error('Auth error:', error);
            throw error;
        }
    }

    static signOut() {
        localStorage.removeItem('accessToken');
        localStorage.removeItem('idToken');
        localStorage.removeItem('refreshToken');
        localStorage.removeItem('currentGameId');
        localStorage.removeItem('attempts');

        const logoutUrl = `https://${config.domain}/logout?client_id=${config.clientId}&logout_uri=${encodeURIComponent(config.loginUri)}`;
        window.location.href = logoutUrl;
    }

    static async callApi(data = {}) {
        const accessToken = localStorage.getItem('idToken');
        if (!accessToken) {
            throw new Error('No access token found');
        }

        try {
            const response = await fetch(config.apiEndpoint, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${accessToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            if (!response.ok) {
                throw new Error(`API call failed: ${await response.text()}`);
            }

            return await response.json();
        } catch (error) {
            console.error('API error:', error);
            throw error;
        }
    }
}
