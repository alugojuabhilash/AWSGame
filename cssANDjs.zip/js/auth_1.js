function login() {
    const cognitoDomain = window.config.domain;
    const clientId = window.config.clientId;
    const redirectUri = window.config.redirectUri;
    
    // Generate a random state value
    const state = generateRandomString(32);
    // Store the state in localStorage to verify when we return
    localStorage.setItem('oauth_state', state);
    
    const loginUrl = `https://${cognitoDomain}/oauth2/authorize?` +
        `client_id=${clientId}&` +
        `response_type=code&` +
        `scope=${encodeURIComponent('openid email profile')}&` +
        `redirect_uri=${encodeURIComponent(redirectUri)}&` +
        `state=${state}`;
    
    console.log('Redirecting to:', loginUrl); // For debugging
    window.location.href = loginUrl;
}

function generateRandomString(length) {
    const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let text = '';
    for (let i = 0; i < length; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
}

async function exchangeCodeForTokens(code) {
    const tokenEndpoint = `https://${window.config.domain}/oauth2/token`;
    const params = new URLSearchParams();
    params.append('grant_type', 'authorization_code');
    params.append('client_id', window.config.clientId);
    params.append('code', code);
    params.append('redirect_uri', window.config.redirectUri);

    try {
        const response = await fetch(tokenEndpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: params
        });

        if (!response.ok) {
            const errorData = await response.json();
            console.error('Token exchange failed:', errorData);
            throw new Error(errorData.error_description || 'Failed to exchange code for tokens');
        }

        const tokens = await response.json();
        console.log('Token exchange successful');
        return tokens;
    } catch (error) {
        console.error('Error exchanging code for tokens:', error);
        throw error;
    }
}


// Add this to auth.js to handle the callback
window.onload = async function() {
    // Only run this code if we're on the callback page
    if (window.location.pathname.includes('callback.html')) {
        const urlParams = new URLSearchParams(window.location.search);
        const code = urlParams.get('code');
        const state = urlParams.get('state');
        const storedState = localStorage.getItem('oauth_state');
        const tokenDisplay = document.getElementById('token-display');
        
        // Verify state parameter
        if (state !== storedState) {
            console.error('State mismatch. Possible CSRF attack');
            tokenDisplay.innerHTML = 'Authentication failed: Invalid state';
            return;
        }
        
        // Clear stored state
        localStorage.removeItem('oauth_state');
        
        if (code) {
            tokenDisplay.innerHTML = 'Processing authentication...';
            try {
                const tokens = await exchangeCodeForTokens(code);
                
                if (tokens.access_token) localStorage.setItem('accessToken', tokens.access_token);
                if (tokens.id_token) localStorage.setItem('idToken', tokens.id_token);
                if (tokens.refresh_token) localStorage.setItem('refreshToken', tokens.refresh_token);
                
                tokenDisplay.innerHTML = 'Authentication successful!';
                // Show game controls
                document.getElementById('game-controls').style.display = 'block';
            } catch (error) {
                console.error('Error exchanging code for tokens:', error);
                tokenDisplay.innerHTML = 'Authentication failed: ' + error.message;
            }
        } else {
            tokenDisplay.innerHTML = 'Authentication failed: No code received';
        }
    }
};

// Add sign out functionality
document.addEventListener('DOMContentLoaded', function() {
    const signOutButton = document.getElementById('signOut');
    if (signOutButton) {
        signOutButton.addEventListener('click', function() {
            // Clear tokens
            localStorage.removeItem('accessToken');
            localStorage.removeItem('idToken');
            localStorage.removeItem('refreshToken');
            // Redirect to index page
            window.location.href = '/index.html';
        });
    }
});
