window.config = {
    clientId: '2hojnjpdom46evnu3qlgihkslf',
    domain: 'number-guess-game-193817168026-us-east-1.auth.us-east-1.amazoncognito.com',
    redirectUri: 'https://d22707e76c60dw.cloudfront.net/callback.html',
    cloudfrontdns: 'https://d22707e76c60dw.cloudfront.net',
    // redirectUri: 'https://d22707e76c60dw.cloudfront.net',
    apiEndpoint: 'https://wappnt0obl.execute-api.us-east-1.amazonaws.com/prod/game',
    loginUri: 'https://d22707e76c60dw.cloudfront.net/index.html'
};
export default config;