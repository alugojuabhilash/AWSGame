import { Auth } from './auth.js';

export class Game {
    constructor() {
        this.gameId = null;
        this.gameActive = false;
        this.attempts = 0;
        this.config = { min: 1, max: 100 }; // Default config
    }

    async startGame() {
        try {
            // Send empty body for new game request
            const response = await Auth.callApi();

            if (response.gameId) {
                this.gameId = response.gameId;
                this.gameActive = true;
                this.attempts = 0;
                localStorage.setItem('currentGameId', this.gameId);
                localStorage.setItem('attempts', '0');
                
                document.getElementById('game-area').style.display = 'block';
                document.getElementById('game-response').innerHTML = response.message;
                document.getElementById('guessInput').value = '';

                // Update input placeholder with game config
                const guessInput = document.getElementById('guessInput');
                guessInput.setAttribute('min', this.config.min);
                guessInput.setAttribute('max', this.config.max);
                guessInput.placeholder = `Enter your guess (${this.config.min}-${this.config.max})`;

                // Display initial leaderboard if provided
                if (response.leaderboard) {
                    this.displayLeaderboard(response.leaderboard);
                }
            } else {
                throw new Error('No game ID received from server');
            }
            
            return response;
        } catch (error) {
            console.error('Start game error:', error);
            document.getElementById('game-response').innerHTML = 'Error starting game. Please try again.';
            throw error;
        }
    }

    async makeGuess(guess) {
        if (!this.gameActive) {
            document.getElementById('game-response').innerHTML = 'Please start a new game first.';
            return;
        }

        // Validate guess against config
        if (guess < this.config.min || guess > this.config.max) {
            document.getElementById('game-response').innerHTML = 
                `Please enter a number between ${this.config.min} and ${this.config.max}`;
            return;
        }

        try {
            this.attempts++;
            localStorage.setItem('attempts', this.attempts.toString());

            const response = await Auth.callApi({
                guess: guess,
                gameId: this.gameId,
                attempts: this.attempts
            });

            document.getElementById('game-response').innerHTML = response.message;

            if (response.gameOver) {
                this.gameActive = false;
                localStorage.removeItem('currentGameId');
                localStorage.removeItem('attempts');
                if (response.leaderboard) {
                    this.displayLeaderboard(response.leaderboard);
                }
            }

            return response;
        } catch (error) {
            console.error('Make guess error:', error);
            document.getElementById('game-response').innerHTML = 'Error submitting guess. Please try again.';
            this.attempts--; // Revert attempt count on error
            localStorage.setItem('attempts', this.attempts.toString());
            throw error;
        }
    }

    // displayLeaderboard(leaderboard) {
    //     if (!leaderboard || !leaderboard.length) {
    //         document.getElementById('leaderboard').innerHTML = 'No scores yet!';
    //         return;
    //     }
        
    //     const leaderboardHtml = `
    //         <h3>Top 10 Players</h3>
    //         <table>
    //             <tr>
    //                 <th>Rank</th>
    //                 <th>Player</th>
    //                 <th>Attempts</th>
    //             </tr>
    //             ${leaderboard.map((score, index) => `
    //                 <tr>
    //                     <td>${index + 1}</td>
    //                     <td>${score.player_name}</td>
    //                     <td>${score.attempts}</td>
    //                 </tr>
    //             `).join('')}
    //         </table>
    //     `;
        
    //     document.getElementById('leaderboard').innerHTML = leaderboardHtml;
    // }

    displayLeaderboard(leaderboard) {
        if (!leaderboard || !leaderboard.length) {
            document.getElementById('leaderboard').innerHTML = `
                <div class="leaderboard-container">
                    <h3>Leaderboard</h3>
                    <p class="no-scores">No scores yet. Be the first to play!</p>
                </div>`;
            return;
        }
        
        const leaderboardHtml = `
            <div class="leaderboard-container">
                <h3>Top Players</h3>
                <table class="leaderboard-table">
                    <thead>
                        <tr>
                            <th>Rank</th>
                            <th>Player</th>
                            <th>Attempts</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${leaderboard.map((score, index) => `
                            <tr class="${index === 0 ? 'top-score' : ''} ${index === 1 ? 'second-score' : ''} ${index === 2 ? 'third-score' : ''}">
                                <td class="rank-${index + 1}">${index + 1}</td>
                                <td>${score.display_name}</td>
                                <td><span class="attempts-badge">${score.attempts}</span></td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
        
        document.getElementById('leaderboard').innerHTML = leaderboardHtml;
    }
    
    

    checkExistingGame() {
        const savedGameId = localStorage.getItem('currentGameId');
        const savedAttempts = localStorage.getItem('attempts');
        if (savedGameId && savedAttempts) {
            this.gameId = savedGameId;
            this.attempts = parseInt(savedAttempts);
            this.gameActive = true;
            document.getElementById('game-area').style.display = 'block';
            return true;
        }
        return false;
    }
}
