let targetNumber;
let attempts;
let gameActive = false;

function startGame() {
    targetNumber = Math.floor(Math.random() * 100) + 1;
    attempts = 0;
    gameActive = true;
    document.getElementById('game-area').style.display = 'block';
    document.getElementById('game-response').innerHTML = 'Game started! Guess a number between 1 and 100.';
    document.getElementById('guessInput').value = '';
    // updateLeaderboard();
}

async function makeGuess() {
    if (!gameActive) return;

    const guessInput = document.getElementById('guessInput');
    const guess = parseInt(guessInput.value);
    
    if (isNaN(guess) || guess < 1 || guess > 100) {
        document.getElementById('game-response').innerHTML = 'Please enter a valid number between 1 and 100.';
        return;
    }

    attempts++;
    
    if (guess === targetNumber) {
        gameActive = false;
        document.getElementById('game-response').innerHTML = 
            `Congratulations! You found the number in ${attempts} attempts!`;
        await saveScore(attempts);
        const response = await updateLeaderboard();
        if (response.leaderboard) {
            displayLeaderboard(response.leaderboard);
        }
    } else if (guess < targetNumber) {
        document.getElementById('game-response').innerHTML = 'Too low! Try again.';
    } else {
        document.getElementById('game-response').innerHTML = 'Too high! Try again.';
    }

    guessInput.value = '';
}

function displayLeaderboard(leaderboard) {
    if (!leaderboard || !leaderboard.length) return;
    
    const leaderboardHtml = `
        <h3>Leaderboard</h3>
        <table>
            <tr>
                <th>Player</th>
                <th>Attempts</th>
            </tr>
            ${leaderboard.map(score => `
                <tr>
                    <td>${score.player_name}</td>
                    <td>${score.attempts}</td>
                </tr>
            `).join('')}
        </table>
    `;
    
    document.getElementById('leaderboard').innerHTML = leaderboardHtml;
}

async function saveScore(attempts) {
    try {
        const token = localStorage.getItem('accessToken');
        if (!token) {
            throw new Error('No authentication token found');
        }

        console.log('Saving score:', attempts);
        console.log('Token:', token.substring(0, 20) + '...');  // Log partial token for debugging

        const response = await fetch(window.config.apiEndpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token  // Add Bearer prefix
            },
            body: JSON.stringify({ score: attempts })
        });

        console.log('Save score response:', response);

        console.log('Save score response status:', response.status);
        console.log('Save score response headers:', [...response.headers.entries()]);

        if (!response.ok) {
            const errorText = await response.text();
            console.error('Save score error response:', errorText);
            throw new Error(`Failed to save score: ${response.status}`);
        }

        const result = await response.json();
        console.log('Save score result:', result);
        return result;
    } catch (error) {
        console.error('Save score error:', error);
        throw error;
    }
}

async function saveScore1(attempts) {
    try {
        const token = localStorage.getItem('accessToken');
        if (!token) {
            throw new Error('No authentication token found');
        }

        console.log('Saving score:', attempts);
        console.log('Token:', token.substring(0, 20) + '...');

        const response = await fetch(window.config.apiEndpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token,
                'Access-Control-Allow-Origin': window.config.cloudfrontdns
            },
            body: JSON.stringify({ 
                score: attempts,
                timestamp: new Date().toISOString()
            }),
            mode: 'cors'
        });

        if (!response.ok) {
            const errorText = await response.text();
            console.error('API Error Response:', errorText);
            throw new Error(`API returned ${response.status}: ${errorText}`);
        }

        const result = await response.json();
        console.log('Save score success:', result);
        return result;

    } catch (error) {
        console.error('Save score error:', error);
        const errorMessage = document.getElementById('game-response');
        if (errorMessage) {
            errorMessage.innerHTML = `<div class="error">Failed to save score. Please try again.</div>`;
        }
        throw error;
    }
}

// function verifyToken() {
//     const token = localStorage.getItem('accessToken');
//     if (token) {
//         console.log('Token exists:', token.substring(0, 20) + '...');
//         // Decode the JWT token to check its expiration
//         try {
//             const base64Url = token.split('.')[1];
//             const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
//             const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
//                 return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
//             }).join(''));

//             const payload = JSON.parse(jsonPayload);
//             console.log('Token payload:', payload);
            
//             if (payload.exp * 1000 < Date.now()) {
//                 console.log('Token expired');
//                 localStorage.removeItem('accessToken');
//                 window.location.href = 'login.html';
//             }
//         } catch (e) {
//             console.error('Error decoding token:', e);
//             localStorage.removeItem('accessToken');
//             window.location.href = 'login.html';
//         }
//     } else {
//         console.log('No token found');
//         window.location.href = 'login.html';
//     }
// }

async function updateLeaderboard() {
    try {
        const token = localStorage.getItem('accessToken');
        
        if (!token) {
            throw new Error('No authentication token found');
        }

        // const response = await fetch(window.config.apiEndpoint, {
        //     method: 'GET',
        //     headers: {
        //         'Authorization': token  // Token already includes 'Bearer '
        //     }
        // });

        const response = await fetch(window.config.apiEndpoint, {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Authorization': token,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify('{}')
        });

        if (!response.ok) {
            const errorText = await response.text();
            console.error('API Error Response:', errorText);
            throw new Error(`API request failed: ${response.status}`);
        }

        // const data = await response.json();
        return await response.json();
    } catch (error) {
        console.error('Leaderboard error:', error);
        document.getElementById('leaderboard').innerHTML = 
            `<div class="error">Error loading leaderboard: ${error.message}</div>`;
    }
}

// Add event listeners for Enter key
// document.addEventListener('DOMContentLoaded', verifyToken);
document.addEventListener('DOMContentLoaded', function() {
    const guessInput = document.getElementById('guessInput');
    if (guessInput) {
        guessInput.addEventListener('keypress', function(event) {
            if (event.key === 'Enter') {
                makeGuess();
            }
        });
    }
});
